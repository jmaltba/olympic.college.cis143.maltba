package com.olympic.cis143.finalproject;

import java.io.Serializable;

public class Card implements Serializable {
	
	/**
	 * @author Jason Maltba
	 */
	
	private static final long serialVersionUID = -8212604189268189523L;

	public enum Rank {

	    ACE("Ace", 1), 
	    KING("King", 10), 
	    QUEEN("Queen", 10), 
	    JACK("Jack", 10), 
	    TEN("10", 10), 
	    NINE("9", 9), 
	    EIGHT("8", 8), 
	    SEVEN("7", 7), 
	    SIX("6", 6), 
	    FIVE("5", 5), 
	    FOUR("4", 4), 
	    THREE("3", 3), 
	    TWO("2", 2);
		
		public final String face;
		public final int value;

		Rank(String face, int value) {
			this.face = face;
			this.value = value;

		} 
    }
	
	public enum Suit {
	    CLUBS, 
	    SPADES, 
	    HEARTS, 
	    DIAMONDS;
	}	
		
    public final Suit suit;
    public final Rank rank;
	public final Rank face;
	public final Rank value;


    public Card (final Suit suit, final Rank rank, final Rank value, final Rank face) {
        this.face = face;
		this.suit = suit;
        this.rank = rank;
        this.value = value;
	}

    public Suit getSuit() {
    	return this.suit;
    }
    
    public Rank getRank() {
    	return this.rank;
    }
    
    public Rank getFace() {
    	return this.face;
    }
    
    public Rank getValue() {
    	return this.value;
    }
    
	public String toString() {
		
		return (this.getFace() + " of " + this.getRank());

	}
	
	public boolean compareSuit(Card card){
		
		return this.suit == card.getSuit();
		
	}
	
	public boolean compareValue(Card card){
		
		return this.value == card.getValue();
	}
	
	public boolean equals(final Card card) {
        if (card.value == this.value && card.suit == this.suit) {
            return true;
        }
        return false;
    }
}
