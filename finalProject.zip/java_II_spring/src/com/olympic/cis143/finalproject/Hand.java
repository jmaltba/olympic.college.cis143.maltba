package com.olympic.cis143.finalproject;

import java.io.Serializable;

public class Hand implements Serializable
{

	/**
	 * @author Jason Maltba
	 */
	private static final long serialVersionUID = -2158037579234306975L;

	private Card[] theHand = new Card[12];

	private int numberOfCards = 0;

	public int calculateTotal() {
		int total =0;
		boolean aceFlag = false;
		for (int i = 0; i < numberOfCards; i++) {
			int value = theHand[i].value.value;
			if (value > 10) {
				value = 10;
			} 
			else if ( value == 1) {
				aceFlag = true;
			}
			total += value;
		}
		if (aceFlag && total + 10 <= 21) {
			total += 10;
		}
		return total;
	}
	public int getHandSize() {
		return this.theHand.length;
	}
	
	public String toString(){
		return this.toString(false, false);
	}
	
	public String toString(boolean isDealer, boolean hideHoleCard){
		String s = "";
		int total =0;
		boolean aceFlag = false;
		String aceString = "";
		for (int i = 0; i < numberOfCards; i++) {
			if ( isDealer && hideHoleCard && i == 0) {
				s = " Showing";
			} 
			else {
				int value = theHand[i].value.value;
				String valueName = theHand[i].getFace().face;
				s += " " + valueName + "" + theHand[i].getSuit();
				
				if ( value == 1) {
					aceFlag = true;
				}
				total += value;
			}
		}
		if (aceFlag && total + 10 <= 21) {
			aceString = " or " + (total + 10);
		}
		if ( hideHoleCard) {
			return s;
		}
		else {
			return s + " totals " + total + aceString;
		}
		
	}
	
	public void addCard(Card card) {
		theHand[numberOfCards++] = card;
	}
	
	public void clearHand() {
		numberOfCards = 0;
	}
	
	public boolean dealerPeek() {
		int value = theHand[1].getValue().value;
		return value == 1;
	}
}
