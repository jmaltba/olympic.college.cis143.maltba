package com.olympic.cis143.finalproject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.olympic.cis143.finalproject.Card.Rank;
import com.olympic.cis143.finalproject.Card.Suit;

public class Deck extends Exception implements Serializable{

	/**
	 * @author Jason Maltba
	 */
	private static final long serialVersionUID = -1122660769976072929L;
	List<Card> deck = new ArrayList<>();

	public Deck() {
		int i = 0;
		while (i < 3) {
			for (Suit s : Suit.values()) {
				for (Rank r : Rank.values()) {
					deck.add(new Card(s, r, r, r));
				}
			}
			i++;
		}
	}
	
	public List<Card> getDeck() {
		return this.deck;
	}
	
	public String toString(){

		String str = "";

		for (int i = 0; i < deck.size(); i++) {
			str +=	deck.toArray()[i].toString() + " ";
		}
		return str;
	}

	public void shuffle() {
		Collections.shuffle(deck);
	}

	public boolean hasNext() {
		if (!this.deck.isEmpty()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Card dealCard() {
		if (hasNext()) {
			return this.deck.remove(0);
		}
		else {
			throw new RuntimeException();
		}
	}
}
