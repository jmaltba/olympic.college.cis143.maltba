package com.olympic.cis143.finalproject;

import java.io.Serializable;

public class Player implements Serializable
{
	
	/**
	 * @author Jason Maltba
	 */
	private static final long serialVersionUID = -3435509076169366886L;
	private int bank;
	private int bet;
	private String name;
	private Hand hand;
	
	public Player() {
		this.bank = 100;
		this.hand = new Hand();	
	}
	
	public int getHandSize() {
		return this.hand.getHandSize();
	}
	
	public int getBank() {
		return this.bank;
	}
	
	public void bust() {
		bank -= bet;
		bet = 0;
	}

	public void win() {
		this.bank += this.bank;
		bet = 0;
	}

	public void loss() {
		this.bank -= this.bet;
		this.bet = 0;
	}
	
	public void removeFromGame() {
		this.bank = -1;
	}
	
	public void resetBank() {
		this.bank = 0;
	}
	
	public void hasBlackjack() {
		this.bank += this.bet * 1.5;
		this.bet = 0;
	}
	
	public void push() {
		this.bet = 0;
	}
	
	public void setBet(int newBet) {
		this.bet = newBet;
	}
	
	public void setName(String name1){
		this.name = name1;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getTotal() {
		return this.hand.calculateTotal();
	}
	
	public int getBet(){
		return this.bet;
	}
		
	public void addCard(Card card) {
		this.hand.addCard(card);
	}
	
	public String getHandString() {
		String str = "Cards:" + this.hand.toString();

		return str;
	}
		
	public void clearHand() {
		hand.clearHand();
	}
		
}
