# Use case
Uour food truck will need to start adding moe items than just Taco's. Many ways we can do this, however, for now, we will create an annotation to do this.
Note that there is no Main class. This is not something, that, at this point, will run.

# You TODO

1. Create an annotation called FoodItem. You will need a method declaration in this file to know the type. Call this method type.
Note that this annotation must be a Runtime annotation. Additionally, it will be on the top of the class at the class level.
2. Create a file called Taco. Annotate this with the FoodItem annotation.
3. Create a file callled Burrito. Annotate this file with the FoodItem annotation.

# Bonus Points
You can create annotations just for developers that have no impact on the actual running of the code.

Look at the following annotations for inspiration and then come up with 1 or 2 more that might be interesting:
https://github.com/stalehd/honestlib/tree/master/src/main/java/no/fluffybunny/honest/annotations