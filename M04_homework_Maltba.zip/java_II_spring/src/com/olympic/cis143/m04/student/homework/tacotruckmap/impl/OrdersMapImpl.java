package com.olympic.cis143.m04.student.homework.tacotruckmap.impl;

import com.olympic.cis143.m04.student.homework.tacotruckmap.OrderDoesNotExistException;
import com.olympic.cis143.m04.student.homework.tacotruckmap.Orders;
import com.olympic.cis143.m04.student.homework.tacotruckmap.TacoImpl;

import java.util.*;

public class OrdersMapImpl implements Orders {
	
	Map<String, ArrayList<TacoImpl>> tacoMap = new HashMap<>();
	List<TacoImpl> tacoList = new ArrayList<>();

    @Override
    public void createOrder(final String orderid) {
    	tacoMap.put(orderid, (ArrayList<TacoImpl>) tacoList);
    }

    @Override
    public void addTacoToOrder(final String orderid, final TacoImpl taco) throws OrderDoesNotExistException {
    	if (tacoMap.containsKey(orderid)) {
        	tacoList.add(taco);
    	}
    	else {
    		throw new OrderDoesNotExistException(orderid);
    	}
    }

    @Override
    public boolean hasNext() {
    	if (howManyOrders() != 0) {
    		return true;
    	}
    	else {
    		return false;
    	}
	}

    @Override
    public List<TacoImpl> closeOrder(final String orderid) throws OrderDoesNotExistException {
        if (hasNext()) {
        	return tacoMap.remove(orderid);
        }
        else {
        	throw new OrderDoesNotExistException(orderid);
        }
    }

    @Override
    public int howManyOrders() {
        return tacoMap.size();
    }

    @Override
    public List<TacoImpl> getListOfOrders(final String orderid) throws OrderDoesNotExistException {
        if (tacoMap.containsKey(orderid)) {
        	return tacoMap.get(orderid);
        }
        else {
        	throw new OrderDoesNotExistException(orderid);
        }
    }
}
