package com.olympic.cis143.m04.student.tacotruck.set;

import java.util.*;

import com.olympic.cis143.m04.student.tacotruck.Orders;
import com.olympic.cis143.m04.student.tacotruck.TacoImpl;

public class OrdersSetImpl implements Orders {
	
	private List<Object> tacoList = new LinkedList<>();
	
    @Override
    public void addOrder(TacoImpl tacoOrder) {
    	if (tacoOrder != null) {
    		this.tacoList.add(tacoOrder);
    	}
    }

    @Override
    public boolean hasNext() {
    	if (howManyOrders() != 0) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }

    @Override
    public TacoImpl closeNextOrder() {
    	if (!tacoList.isEmpty()) {
			return (TacoImpl) tacoList.remove(0);
    	}
    	else {
    		return null;
    	}
    }

    @Override
    public int howManyOrders() {
        return tacoList.size();
    }
}
